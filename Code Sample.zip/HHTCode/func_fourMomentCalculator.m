function [m v s k] = func_fourMomentCalculator(input_data)
%FUNC_FOURMOMENTCALCULATOR Summary of this function goes here
%   Calculate the first four statistical moments based on the input data.


%Calculating the mean
m=sum(input_data)/length(input_data);

% Calculating the variance
v=0.0;
for i=1:length(input_data)
    v=v+(input_data(i)-m)^2;
end
v=v/(length(input_data)-1);

%calculate skiwness
s=0.0;
for i=1:length(input_data)
    s=s+(input_data(i)-m)^3;
end
s=s/((length(input_data)-1)*(v*sqrt(v)));

% Calculate Kurtosis
k=0.0;
for i=1:length(input_data)
    k=k+(input_data(i)-m)^4;
end
k=k/((length(input_data)-1)*(v^2));

return

