function featuresVector = func_HHTW(image)
%FUNC_HHTW Summary of this function goes here
%   This image get the input as Image and return the feature vectors based
%   on the Hilbert Hang transform and Wavlet Decompression

% Read image
targetImage=imread(image);

% Create two vector based on as a input signal for generating the features
% using the rows and columns of the image and read them in snake direction

%change the image just to YCbCr

targetImage=rgb2ycbcr(targetImage);

% Normalize and convert the image type to Double
%targetImage=im2double(targetImage);

% Get the Y color channel for starting the feature generation
lImage=targetImage(:,:,1);

%imshow(lImage);


% For this purpose we should first read the image size
%imshow(lImage);

 RowsArray=[];
 ColumnsArray=[];
 
 [rows columns dimenstion]=size(lImage);
 
 for i=1:rows
     RowsArray=[RowsArray lImage(i,:)];
     lImage=fliplr(lImage);
 end
 
 lImage=targetImage(:,:,1)';
 
 %imshow(lImage);
 
[rows columns dimenstion]=size(lImage);

for i=1:rows
     ColumnsArray=[ColumnsArray lImage(i,:)];
     lImage=fliplr(lImage);
end
 
%Get the emd of each signal

RowsArray=double(RowsArray);
ColumnsArray=double(ColumnsArray);

% Combine two  vector
emdRows=emd(RowsArray);
emdCols=emd(ColumnsArray);


% Get the Hilbert Spectrum of extracted EMD's.

 
 [A,f,tt]=hhspectrum(emdRows(1:end-1,:));
 
 % Find HHT spectrum
featuresVector=[];

% Calculate features for row signal
for i=1:4
    % Get each Row and calculate first four statistics for them and save
    % the result in feature vector
    [m v s k]=func_fourMomentCalculator(A(i,:));
    featuresVector=[featuresVector m v s k];
    [m v s k]=func_fourMomentCalculator(f(i,:));
    featuresVector=[featuresVector m v s k];
end

[A,f,tt]=hhspectrum(emdCols(1:end-1,:));
 
% Calculate features for row signal
for i=1:4
    % Get each Row and calculate first four statistics for them and save
    % the result in feature vector
    [m v s k]=func_fourMomentCalculator(A(i,:));
    featuresVector=[featuresVector m v s k];
    [m v s k]=func_fourMomentCalculator(f(i,:));
    featuresVector=[featuresVector m v s k];
end

return

